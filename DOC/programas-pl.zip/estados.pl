/***********************************************************
 BUSQUEDA DE SOLUCIONES DE PROBLEMAS DE ESTADO INDEPENDIENTE
 DEL PROBLEMA CONCRETO.

 Un problema de estado queda definido por una coleccion de estados,
 entre los que se distingue un estado inicial y uno o mas estados finales,
 y una noci�n de 'movimiento valido' o 'transicion' entre estados.
 
 Una solucion al problema consiste en una secuencia de movimientos validos
 que llevan del estado inicial a uno final.
 
 En este programa, la busqueda se realiza de modo bottom-up ( hacia adelante ),
 es decir, partiendo del estado inicial.

Cada problema concreto requiere a�adir reglas para definir
los predicados
   inicial(Estado_inicial)
   final(Estado_final)
   movimiento(Estado_previo,Movimiento,Estado_nuevo). 
     'Movimiento' es el nombre del movimiento. 
     No hace falta definir la coleccion de nombres de movimiento   
*************************************************************/

/***********************************************************
 solucion(LM,LE):<-> LM es una lista de movimientos que transforman
                     el estado inicial en uno final.
                     LE es la lista de estados por los que se ha pasado
                        en ese recorrido

 solucion(E,Visitados,LM,LE):<-> Partiendo del estado E se puede
     llegar a un estado final realizando los movimientos de la
     lista LM y pasando por los estados de la lista LE.
     Visitados es la lista de estados visitados antes de E

*************************************************************/

solucion(LM,LE) :-
   inicial(E),
   solucion(E,[],LM,LE).

solucion(E,Visitados,[],[E]) :-
   final(E).
solucion(E,Visitados,[M|LM],[E|LE]) :-
   movimiento(E,M,E1),
   \+ member(E1,[E|Visitados]),     % controlamos que el movimiento no nos lleve a un estado ya visitado
   solucion(E1,[E|Visitados],LM,LE).


/************************  UN EJEMPLO ***********************
EL PROBLEMA DE LAS JARRAS: partiendo de dos jarras vacias, de
capacidades 5 y 3 litros, y un grifo para llenarlas cuando se
quiera, queremos  dejar un litro en la jarra grande.

Representacion de estados y movimientos:

  Estado: [I,J]  donde  I,J son enteros tales que
                 0 <= I <= 5  (contenido de la grande)
                 0 <= J <= 3  (contenido de la peque�a)

  Estado inicial: [0,0]
  Estado_final: [1,_]

  Movimientos: llenar p,llenar g,vaciar p,vaciar g,
               p -> g, g -> p
************************************************************/

inicial([0,0]).

final([1,_]).

movimiento([I,J],'llenar p',[I,3]).
movimiento([I,J],'llenar g',[5,J]).
movimiento([I,J],'vaciar p',[I,0]).
movimiento([I,J],'vaciar g',[0,J]).
movimiento([I,J],'p -> g  ',[NI,0])
    :- NI is I+J, NI =< 5.
movimiento([I,J],'p -> g  ',[5,NJ])
    :- S is I+J, S > 5, NJ is S-5.
movimiento([I,J],'g -> p  ',[0,NJ])
    :- NJ is I+J, NJ =< 3.
movimiento([I,J],'g -> p  ',[NI,3])
    :- S is I+J, S > 3, NI is S-3.

/********************************************************

El problema tiene 31 soluciones, la mas corta de las cuales
viene dada por la lista
[llenar p,p -> g,llenar p,p -> g,vaciar g,p -> g]

Esta solucion es la novena que se encuentra al utilizar el programa anterior.

Para obtener directamente la solucion con menos movimientos podemos usar setof/3.
Ojo, esto presentara problemas si el espacio de busqueda es muy grande, pues setof
exige explorarlo por completo.
*********************************************************/

solucion_mas_corta(LM1,LE1) :-
   setof((N,LM,LE), 
         (solucion(LM,LE),length(LM,N)),
         [(N1,LM1,LE1) | _]
        ). 


/********************************************************
Una rutina simple  para mostrar la solucion
muestra(+LM,+LE) <-> muestra emparejado cada movimiento de LM  con el estado de LE al que lleva.

El codigo usa que LE tendra un elemento mas que LM
*********************************************************/

muestra(LM,[E|LE]) :-
    write('========== Solucion =========='),nl,
    write('El estado inicial es         '),
    write(E),
    nl,
    muestra1(LM,LE).

muestra1([],[]):- 
    nl.
muestra1([M|LM],[E|LE]) :-
    write(M),
    write('  conduce al estado  '),
    write(E),
    nl,
    muestra1(LM,LE).   

