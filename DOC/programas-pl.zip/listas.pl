% Algunos ejercicios sobre listas

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% elimina(X,Xs,Ys)  <-> Ys es el resultado de eliminar las apariciones de X en Xs 
%% elimina1(X,Xs,Ys) <-> Ys es el resultado de eliminar la primera aparici�n de X en Xs 
%%                       (la propia Xs si hay aparici�n de X)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

elimina(_,[],[]).
elimina(X,[X|Xs],Ys) :- 
  !,elimina(X,Xs,Ys).
elimina(X,[Y|Xs],[Y|Ys]) :- 
  elimina(X,Xs,Ys).

elimina1(_,[],[]).
elimina1(X,[X|Xs],Xs) :- 
  !.
elimina1(X,[Y|Xs],[Y|Ys]) :- 
  elimina1(X,Xs,Ys).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% cansina(Xs) <-> todos los elementos de la lista Xs son iguales
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cansina([]).
cansina([X]).
cansina([X,X|Xs]) :- cansina([X|Xs]).

% O bien
cansina1([]).
cansina1([X|Xs]) :- cansinaux(X,Xs).

% cansinaux(X,Xs) <-> todos los elementos de Xs son iguales a X
cansinaux(_,[]).
cansinaux(X,[X|Xs]) :- cansinaux(X,Xs).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ultimo(Xs,X) <-> X es el ultimo elemento de la lista Xs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Programamos tres variantes. Las dos �ltimas ocultan la recursi�n. Las tres son lineales
ultimo([X],X).
ultimo([_|Xs],X) :- ultimo(Xs,X).

ultimo1(Xs,X) :- append(_,[X],Xs).

ultimo2(Xs,X) :- reverse(Xs,[X|_]).  % reverse es la versi�n lineal de la inversi�n de listas

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% prefijo(Xs,Ys) <-> la lista Xs es un prefijo de la lista Ys
% sufijo(Xs,Ys) <-> la lista Xs es un sufijo de la lista Ys
% sublista(Xs,Ys) <-> la lista Xs es una sublista de la lista Ys
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Por recursi�n directa
prefijo([],Ys).
prefijo([X|Xs],[X|Ys]) :- 
  prefijo(Xs,Ys).

sufijo(Ys,Ys).
sufijo(Xs,[Y|Ys]) :- 
  sufijo(Xs,Ys).

sublista(Xs,Ys) :- 
  prefijo(Xs,Ys).
sublista(Xs,[_|Ys]) :- 
  sublista(Xs,Ys).

% O bien, m�s elegante, en t�rminos de otros predicados previos
prefijo1(Xs,Ys) :- 
  append(Xs,Zs,Ys).
sufijo1(Xs,Ys) :- 
  append(Zs,Xs,Ys).
sublista1(Xs,Ys) :- 
  sufijo(Zs,Ys),
  prefijo(Xs,Zs).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Programa sendos predicados prefijos/2 y sufijos/2 especificados como:
%% prefijos(Lista,Prefijos) <-> Prefijos es la lista de todos los prefijos de Lista.
%% sufijos(Lista,Sufijos)   <-> Sufijos es la lista de todos los sufijos de Lista.
%% 
%% Ejemplo: sufijos([a,b],L) deber tener �xito devolviendo en L una lista cuyos elementos son [], [b] y
%% [a,b], aunque no necesariamente en ese orden. An�logamente para prefijos/2.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

prefijos([],[[]]).  % ojo a [[]], poner [] estar�a mal
prefijos([X|Xs],[[]|Ys]) :-
  prefijos(Xs,Zs), % obtenemos los prefijos del resto Xs
  pega(X,Zs,Ys).   % y pegamos X en cabeza de cada uno

% pega(X,Yss,Zss) <-> Zss es la lista resultante de a�adir como cabeza X a cada elemento de la lista
%                     de listas Yss
pega(X,[],[]).
pega(X,[Ys|Yss],[[X|Ys]|Zss]) :- pega(X,Yss,Zss).

% Sufijos es m�s f�cil...
sufijos([],[[]]).
sufijos([X|L],[[X|L]|Ys]):-
    sufijos(L,Ys).

%% Estos predicados de 'agregaci�n de respuestas' pueden tambi�n programarse mediante
%% algunos predicados primitivos de Prolog que no hemos visto: bagof/3, findall/3, setof/3

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% (a) nomiembro(X,L) <-> X no es un elemento de la lista L.
%% (b) hazconjunto(L,C) <-> C es un conjunto, representado por medio de una lista, que tiene los mismos
%%                          elementos que la lista L, pero sin que ninguno este repetido.
%% (c) union(C1,C2,C) <-> C es el conjunto formado por los elementos de la uni�n de los conjuntos C1 y C2.
%% (d) interseccion(C1,C2,C) <-> C es el conjunto formado por los elementos de la intersecci�n de los conjuntos C1 y C2.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%% nomiembro %%%%%%%%%
% Usando el predicado primitivo \=/2 
% X \= Y <-> X e Y no son unificables. 
% Es definible mediante las dos siguientes cl�usulas
% X \= Y :-  X=Y,!,fail.  % fail es un predicado sin cl�usula, por lo que siempre falla, forzando el backtraking
% X \= Y.
% O bien, usando el tambi�n predicado primitivo \+/1 (le�do como 'not')
% X \= Y :- \+ (X=Y).
% \+, a su vez, es definible como 
% \+ G :- G,!,fail.
% \+ G.

nomiembro(_,[]).
nomiembro(X,[Y|Ys]) :-
    X \= Y,
    nomiembro(X,Ys).

% Otra versi�n: Usando la negaci�n de Prolog 
nomiembro1(X,L) :- \+ member(X,L).

% Donde member/2 se define del modo usual

member(X,[X|_]).
member(X,[_|Xs]) :- member(X,Xs).

    
% N�tese que ninguna de las dos versiones es un programa l�gico puro
% debido al uso de \+ y \=. Ninguna de ellas es reversible (pues \+ y \= lo son).
% No hay modo de programar como programa l�gico puro la desigualdad
% pues har�a falta un n�mero infinito de cl�usulas.
    

%%%%%%%% hazconjunto %%%%%%%%%
hazconjunto([],[]).
hazconjunto([X|Xs],[X|Ys]) :- 
    nomiembro(X,Xs),
    hazconjunto(Xs,Ys).

hazconjunto([X|Xs],Ys) :- 
    member(X,Xs),
    hazconjunto(Xs,Ys).

% En la versi�n anterior, se comprueba dos veces (por backtracking) la pertenencia de X a Xs
% (una vez en negativo y otra en positivo). Ademas, el test member(X,Xs) puede tener �xito varias veces.
% Para evitarlo, debemos usar corte (!) o recursos an�logos de control de la b�squeda

% Usando !
hazconjunto1([],[]).

hazconjunto1([X|Xs],Ys) :- 
    member(X,Xs),!,
    hazconjunto1(Xs,Ys).

hazconjunto1([X|Xs],[X|Ys]) :- 
    hazconjunto1(Xs,Ys).



%%%%%%%% union e interseccion %%%%%%%%%
% Como en el apartado anterior, suponemos que la representaci�n de conjuntos es mediante
% listas sin repeticiones, pero no necesariamente ordenadas.

union([],Ys,Ys).
union([X|Xs],Ys,Zs) :-
    member(X,Ys),
    union(Xs,Ys,Zs).
union([X|Xs],Ys,[X|Zs]) :-
    nomiembro(X,Ys),
    union(Xs,Ys,Zs).

interseccion([],Ys,[]).
interseccion([X|Xs],Ys,[X|Zs]) :-
    member(X,Ys),
    interseccion(Xs,Ys,Zs).
interseccion([X|Xs],Ys,Zs) :-
    nomiembro(X,Ys),
    interseccion(Xs,Ys,Zs).

% Como en el caso de hazconjunto/2, podemos evitar reiteraci�n en la comprobaci�n de que X est� o no en Ys
% La siguiente version lo hace as�, mediante el uso del corte

union1([],Ys,Ys).
union1([X|Xs],Ys,Zs) :-
    member(X,Ys),!,
    union1(Xs,Ys,Zs).
union1([X|Xs],Ys,[X|Zs]) :-
    union1(Xs,Ys,Zs).

interseccion1([],Ys,[]).
interseccion1([X|Xs],Ys,[X|Zs]) :-
    member(X,Ys),!,
    interseccion1(Xs,Ys,Zs).
interseccion1([X|Xs],Ys,Zs) :-
    interseccion1(Xs,Ys,Zs).


% Aun otra versi�n, algo mejorada, tambi�n con !: en las anteriores para union/3, si resulta  que
% X est� en Ys, es innecesario mantener X en Ys para posteriores comprobaciones.
% Para arreglarlo, podemos reemplazar member(X,Ys) por otro predicado elimina(X,Ys,Ys1)
% especificado como: elimina(X,Ys,Ys1) <-> Ys1 es el resultado de eliminar
%                                          la primera aparici�n de X en Ys.
%                                           Si no est�, Ys1 es Ys
% Al suponer que las listas no tienen repeticiones, basta eliminar la primera aparici�n

union2([],Ys,Ys).
union2([X|Xs],Ys,[X|Zs]) :-  % atenci�n, ahora debemos poner X en cabeza del resultado
    elimina(X,Ys,Ys1),!,
    union2(Xs,Ys1,Zs).

elimina(X,[],[]).
elimina(X,[X|Ys],Ys) :- !.  
elimina(X,[Y|Ys],[Y|Zs]) :- 
    elimina(X,Ys,Zs).

% Hacer algo similar para intersecci�n

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escribe un programa en Prolog para definir el siguiente predicado.
%% sumintersec(L1,L2,N) <-> L1 y L2 son dos listas de enteros, ordenadas de menor a mayor y N es la suma
%%                          de los elementos que est�n en la intersecci�n de las dos listas.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Vamos a hacerlo en un solo recorrido de las listas, aprovechando que est�n ordenadas

sumintersec([],Ys,0).
sumintersec([X|Xs],[],0).
sumintersec([X|Xs],[Y|Ys],N) :-
    X < Y,
    sumintersec(Xs,[Y|Ys],N).
sumintersec([X|Xs],[X|Ys],N) :-
    sumintersec(Xs,Ys,N1),
    N is N1+X.
sumintersec([X|Xs],[Y|Ys],N) :-
    X > Y,
    sumintersec([X|Xs],Ys,N).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% palindrome(Xs) <-> Xs es un pal�ndrome
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
palindrome(Xs) :-
  reverse(Xs,Xs).
% ?- palindrome("dabale arroz a la zorra el abad").
% false.
% 2 ?- palindrome("dabalearrozalazorraelabad").
% true.

% Versi�n que ignora los espacios.
palindrome1(Xs) :-
   quitaespacios(Xs,Ys),
   palindrome(Ys).

quitaespacios([],[]).
quitaespacios([32|Xs],Ys) :-
  quitaespacios(Xs,Ys).
quitaespacios([X|Xs],[X|Ys]) :-
  X \= 32,
  quitaespacios(Xs,Ys).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% permut(Xs,Ys) <-> Ys es una permutaci�n de Xs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

permut([],[]).
permut(Xs,[X|Ys]) :-
  select(X,Xs,Zs),
  permut(Zs,Ys).

% select(X,Xs,Ys) <-> Ys es el resultado de quitar a Xs el elemento X (que debe estar en Xs)
select(X,[X|Xs],Xs).
select(X,[Y|Xs],[Y|Ys]) :-
  select(X,Xs,Ys).

% Se puede programar de muchas otras formas; es instructivo pensar alguna 



