% meta.pl. Algunos ejemplos de predicados metal�gicos

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% nvars(T,N) <-> N es el n�mero de variables que tiene T
% Cada aparici�n de variable cuenta
% Ej: nvars(f(g(X,a),Y,h(X,b)),N) debe tener �xito con N = 3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nvars(X,1) :-
  var(X),!.
  
nvars(X,N) :-
  X =.. [_|Args],
  nvars_l(Args,N).

nvars_l([],0).
nvars_l([X|Xs],N) :-
  nvars(X,N1),
  nvars_l(Xs,N2),
  N is N1+N2.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ground(X) <-> X es b�sico (ground), es decir, no contiene variables.
% ground/1 es realmente predefinido, por lo que en el c�digo siguiente
% definimos un predicado gr/1, para que no colisione con ground/1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

gr(X) :-
  nonvar(X), % o bien \+ var(X)
  X =..[F|Args],
  gr_l(Args).

% gr_l(Xs) <-> todos los elementos de Xs son ground
gr_l([]).
gr_l([X|Xs]) :- 
  gr(X),
  gr_l(Xs).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% term_atomic(X,Xs) <-> Xs es la lista de subt�rminos at�micos de X
% Ej: term_atomic(f(g(X,a),0,h(a,b)),X) debe tener �xito con X = [a,0,a,b]
% La especificaci�n no dice nada sobre el orden, ni sobre la eliminaci�n de repeticiones,
% de modo que nos despreocupamos de eso.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
term_atomic(X,[]) :-
  var(X),!.
term_atomic(X,[X]):-
  atomic(X),!.
term_atomic(X,Xs) :-
  X =.. [F|Args],
  term_atomic_l(Args,Xs).

% term_atomic_l(Ts,Xs) <-> Xs es la lista de subt�rminos at�micos de los elementos de la lista Ts
term_atomic_l([],[]).
term_atomic_l([T|Ts],Xs) :-
  term_atomic(T,Xs1),
  term_atomic_l(Ts,Xs2),
  append(Xs1,Xs2,Xs).  % Se puede eliminar este append usando un parametro acumulador

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% subterm(X,Y) <-> X es un subtermino de Y
% Ej: subterm(X,f(Y,g(a,b))) dar�, por bactracking, las siguientes soluciones 
%      (no necesariamente en este orden)
% X = f(Y,g(a,b))
% X = Y
% X = g(a,b)
% X = a
% X = b
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

subterm(X,X).
subterm(X,Y) :-
  nonvar(Y),
  Y =.. [F|Args],
  subterm_l(X,Args).

%subterm_l(X,Ys) <-> X es un subtermino de alguno de los elementos de la lista Ys
subterm_l(X,[Y|Ys]) :-
  subterm(X,Y).
subterm_l(X,[Y|Ys]) :-
  subterm_l(X,Ys).
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reemplaza(X,Y,Arbol1,Arbol2) <-> Arbol1 y Arbol2 son �rboles binarios con la representaci�n 
%  habitual, y Arbol2 es el resultado de reemplazar en Arbol1 cada nodo id�ntico al t�rmino X 
%  por el t�rmino Y.
% Ej: reemplaza(g(a),b,arbol(f(g(a)),arbol(g(a),void,void),arbol(g(X),void,void)),Y) tiene �xito con respuesta
% Y = arbol(f(g(a)), arbol(b, void, void), arbol(g(X), void, void)) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

reemplaza(_,_,void,void).
reemplaza(X,Y,arbol(X1,I,D),arbol(Y,I1,D1)):-
  X==X1,  % podemos reemplazar == por = si estamos seguros que ni X ni X1 tienen variables
  reemplaza(X,Y,I,I1),
  reemplaza(X,Y,D,D1).
reemplaza(X,Y,arbol(Z,I,D),arbol(Z,I1,D1)):-
  X \== Z, % podemos reemplazar \== por \= si estamos seguros que ni X ni Z tienen variables
reemplaza(X,Y,I,I1),
reemplaza(X,Y,D,D1).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reemplaza_t(X,Y,T,T1) <-> T1 es el resultado de reemplazar por Y  cada subt�rmino id�ntico a  X en el t�rmino T.
% Ej: reemplaza_t(g(a),b,f(f(g(a),g(a,b),g(g(a)))),T) tiene �xito con respuesta
% T = f(f(b,g(a,b),g(b))) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

reemplaza_t(X,Y,T,Y) :-
  X == T.
reemplaza_t(X,Y,T,T) :-
  X \== T,
  var(T).
reemplaza_t(X,Y,T,T) :-
  X \== T,
  atomic(T).
reemplaza_t(X,Y,T,T1) :-
  X \== T,
  compuesto(T),
  T =.. [F|Args],                % descomponemos T,
  reemplaza_t_l(X,Y,Args,Args1), % le hacemos el apa�o argumento a argumento,
  T1 =.. [F|Args1].              % y volvemos a juntar las piezas

% reemplaza_t_l(X,Y,Ts,T1s) <-> T1s es el resultado de reemplazar por Y cada subt�rmino id�ntico a X en cada elemento de la lista Ts.
reemplaza_t_l(X,Y,[],[]).
reemplaza_t_l(X,Y,[T|Ts],[T1|T1s]) :-
  reemplaza_t(X,Y,T,T1),
  reemplaza_t_l(X,Y,Ts,T1s).
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% cambia(X,Cambios,Y) <-> Y es el resultado de efectuar en el t�rmino X
%%                         los reemplazamientos indicados en Cambios
%%                         que es una lista de parejas (A,B), que indica
%%                         que cada aparici�n de A debe cambiarse por el t�rmino B.
%%                         Suponemos que X es b�sico (o sea, no tiene variables),
%%                         que en las parejas A es un �tomo,
%%                         y que los cambios de Cambios son simult�neos
%%
%% Ej: cambia(f(g(a),a,a(a,b)),[(b,g(a)),(a,c)],Y) tiene �xito con
%%       Y = f(g(c),c,a(c,g(a)))
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


cambia(X,Cambios,Y) :-
  atom(X),
  member((X,Y),Cambios),
  !.
  
cambia(X,Cambios,Y) :-
  atom(X),             
  !,
  Y=X.
  
cambia(X,Cambios,Y) :- 
  X =.. [F|Args],
  cambia_args(Args,Cambios,Args1), 
  Y =.. [F|Args1].

cambia_args([],Cambios,[]).
cambia_args([A|As],Cambios,[A1|As1])   :-
  cambia(A,Cambios,A1),
  cambia_args(As,Cambios,As1).
  
%% Ejercicio: modificar cambia/3 suponiendo que los cambios no son simult�neos
%%            sino consecutivos seg�n vienen en la lista
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% unify(T,S) <-> T y S son unificables (con occur_check)
% Es  decir, que debe fallar la unificaci�n una variable X con un t�rmino T
% no id�ntico a X pero que contiene a X.
% Por ejemplo, unify(X,f(a,X)) debe fallar, a diferencia de la unificaci�n
% de Prolog, X=f(a,X), que tiene �xito creando una ligadura 'circular' para X.
% Al igual que T=S, la resoluci�n de unify(T,S) lleva a cabo la unificaci�n,
% si es que T y S son unificables
% Por ejemplo, unify(f(X,a),f(b,Y)) debe tener �xito con la respuesta X=b,Y=a
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

unify(T,S) :-
  var(T),
  var(S),T=S.

unify(T,S) :-
  var(T),
  nonvar(S),
  \+ occurs(T,S),  
  T=S.

unify(T,S) :-
  nonvar(T),
  var(S),
  unify(S,T).

unify(T,S) :- 
  nonvar(T),
  nonvar(S),
  T =.. [F|As],
  S =.. [F|Bs],
  unify_l(As,Bs).

unify_l([],[]).
unify_l([A|As],[B|Bs]) :-
  unify(A,B),
  unify_l(As,Bs).

% occurs(X,T) <-> X (que se sabe que es una variable) aparece en T
% occurs es indeterminista (tiene un �xito por cada aparici�n de X en T)
% pero eso no importa, porque en unify/2 se usa en la forma \+ occurs(T,S),
% y \+ tiene un ! en su definici�n

occurs(X,Y) :- 
  var(Y),!,Y==X.
occurs(X,Y) :-
  Y =.. [_|Args],
  occurs_l(X,Args).

occurs_l(X,[Y|_]) :- occurs(X,Y).  % Se podr�a poner un corte aqu�, pero no es preciso 
occurs_l(X,[_|Ys]) :- occurs_l(X,Ys).

% Otra versi�n, en las que algunas condiciones de  las cl�usulas de unify
% se reemplazan por cortes

unify1(T,S) :-
  var(T),
  var(S),!,
  T=S.

unify1(T,S) :-
  var(T),!,
  \+ occurs(T,S),  
  T=S.

unify1(T,S) :-
  var(S),!,
  unify1(S,T).

unify1(T,S) :- 
  T =.. [F|As],
  S =.. [F|Bs],
  unify_l1(As,Bs).

unify_l1([],[]).
unify_l1([A|As],[B|Bs]) :-
  unify1(A,B),
  unify_l1(As,Bs).

