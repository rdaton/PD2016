% Algunos ejercicios sobre �rboles

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% �rboles binarios: representados como void  |  arbol(Elemento,HijoIzdo,HijoDcho)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% simetricos(A1,A2) <-> A1 y A2 son sim�tricos uno de otro
%% sumatree(A,N) <-> A es un �rbol con n�meros en los nodos y N es la suma de esos nodos
%% maxveces(A,X) <-> X es el elemento que aparece m�s veces en A
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% simetricos
simetricos(void,void).
simetricos(arbol(X,HI1,HD1),arbol(X,HI2,HD2)) :-
    simetricos(HI1,HD2),
    simetricos(HD1,HI2).

%% sumatree
sumatree(void,0).
sumatree(arbol(X,HI,HD),M) :- 
    sumatree(HI,N1),
    sumatree(HD,N2),
    N is X+N1+N2.  
    
%% maxveces
% Versi�n m�s directa: vamos recorriendo el �rbol y manteniendo lista de pares (X,VecesX). 
% Despu�s,  recorremos la lista de pares para buscar X tal que VecesX sea m�ximo.
% Si hay varios X con VecesX m�ximo, devolvemos uno cualquiera de ellos.

maxveces(A,X) :- 
    calcula_veces(A,ListaVeces),
    busca_max(ListaVeces,(X,_)).

calcula_veces(A,LV) :- calcula_veces(A,[],LV).  % Predicado auxiliar con acumulador

calcula_veces(void,LV,LV).
calcula_veces(arbol(X,I,D),Acum,LV) :-
   incrementa(X,Acum,Acum1),
   calcula_veces(I,Acum1,Acum2),
   calcula_veces(D,Acum2,LV).

incrementa(X,[],[(X,1)]).
incrementa(X,[(X,V)|LV],[(X,V1)|LV]) :- V1 is V+1.   
incrementa(X,[(Y,V)|LV],[(Y,V)|LV1]) :- 
    X \= Y, 
    incrementa(X,LV,LV1).
       
busca_max([(X,V)],(X,V)).
busca_max([(X,VX)|XsVs],(Y,V)) :- 
    busca_max(XsVs,(X1,V1)),
    max_v((X,VX),(X1,V1),(Y,V)).

max_v((X,VX),(Y,VY),(X,VX)) :- VX >= VY.
max_v((X,VX),(Y,VY),(Y,VY)) :- VX <  VY.
       
    
% Ejercicio: modificar el pograma para que en el acumulador
% est� siempre en cabeza el elemento m�s repetido hasta ese momento

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Recorridos en un �rbol
%% preorden(Arbol,Nodos) <-> Nodos es la lista de nodos de Arbol, recorrido en pre-orden
%% postorden(Arbol,Nodos) <-> Nodos es la lista de nodos de Arbol, recorrido en postorden
%% inorden(Arbol,Nodos) <-> Nodos es la lista de nodos de Arbol, recorrido en inorden
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%  Recorrido en pre-orden %%%%%%%%%%%%%
preorden(void,[]).
preorden(arbol(X,I,D),Orden):-
   preorden(I,OrdenI),
   preorden(D,OrdenD),
   append([X|OrdenI],OrdenD,Orden).

% Variante que pone la ra�z X directamente en cabeza

preorden_a(void,[]).
preorden_a(arbol(X,I,D),[X|Orden]):-
   preorden_a(I,OrdenI),
   preorden_a(D,OrdenD),
   append(OrdenI,OrdenD,Orden).

% Recorrido en preorden con par�metro acumulador
preorden1(Arbol, Nodos) :- preorden1(Arbol,[],Nodos).

% preorden1(Arbol,Acum, PreOrden_Acum) <-> PreOrden_Acum es el resultado de 
%   concatenar los nodos de Arbol en preorden con Acum

preorden1(void,Acum,Acum).
preorden1(arbol(X,I,D),Acum,[X|Orden]):-
   preorden1(D,Acum,OrdenD),
   preorden1(I,OrdenD,Orden).

%%%%%%%%%%%%%  Recorrido en postorden %%%%%%%%%%%%%
postorden(void,[]).
postorden(arbol(X,I,D),Orden):-
   postorden(I,OrdenI),
   postorden(D,OrdenD),
   append(OrdenI,OrdenD,OrdenID),
   append(OrdenID,[X],Orden).

% Recorrido en postorden con par�metro acumulador
postorden1(Arbol, Nodos) :- postorden1(Arbol,[],Nodos).

% postorden1(Arbol,Acum, PostOrden_Acum) <-> PostOrden_Acum es el resultado de 
%   concatenar los nodos de Arbol en postorden con Acum

postorden1(void,Acum,Acum).
postorden1(arbol(X,I,D),Acum,Orden):-
   postorden1(D,[X|Acum],OrdenD),
   postorden1(I,OrdenD,Orden).


%%%%%%%%%%%%%  Recorrido en inorden %%%%%%%%%%%%%
inorden(void,[]).
inorden(arbol(X,I,D),Orden):-
   inorden(I,OrdenI),
   inorden(D,OrdenD),
   append(OrdenI,[X|OrdenD],Orden).

% Recorrido en inorden con par�metro acumulador
inorden1(Arbol, Nodos) :- inorden1(Arbol,[],Nodos).

% inorden1(Arbol,Acum, InOrden_Acum) <-> InOrden_Acum es el resultado de concatenar
%    los nodos de Arbol en inorden con Acum
inorden1(void,Acum,Acum).
inorden1(arbol(X,I,D),Acum,Orden):-
   inorden1(D,Acum,OrdenD),
   inorden1(I,[X|OrdenD],Orden).
