/***************************************************************
                FORMULAS PROPOSICIONALES
                ========================

Este programa ilustra:
- Declaracion y uso de operadores infijos y prefijos
- Uso de la negacion (y doble negacion)
****************************************************************/

:- op(600,xfy,&).     % Se declaran &,\/,->,<-> como operadores infijos
:- op(700,xfy,\/).    % todos asociativos por la derecha. Menor numero indica mayor prioridad
:- op(750,xfy, ->).   
:- op(750,xfy, <->).  

:- op(500,fy,no).     % Se declara 'no' como operador prefijo asociativo
                      % con mas prioridad que los demas

:- op(800,xfx,es).    % El operador 'es' se introduce para expresar la evaluacion 
                      % de formulas. Es infijo y no asociativo 

/******************* Representacion de formulas ************
- Los valores de verdad se representan por 't' y 'f'
- Las variables proposicionales p,q, etc se representan como variables Prolog P,Q, etc.
- Las formulas se construyen usando variables proposicionales y las conectivas de arriba 

Ejemplos de formulas:
  A & (B \/ C)
  (A -> B \/ C) & (B -> no A) & A  -> C
  (A -> B \/ C) & (B -> no A) & (C -> B) & A
  (A -> B \/ C) & (B -> no A) & (C -> B) <-> D
  ******************************/

t es t :- !.   
f es f :- !.   % No quitar estos cortes!!

X & Y es t :- X es t, Y es t.
X & Y es f :- X es f.
X & Y es f :- Y es f.

X \/ Y es f :- X es f, Y es f.
X \/ Y es t :- X es t.
X \/ Y es t :- Y es t.

no X es t :- X es f.
no X es f :- X es t.

X  -> Y es T :-  no X \/ Y es T.
X <-> Y es T :-  (X -> Y) & (Y -> X) es T.


satisfactible(F)  :- F es t.         % Test de satisfactibilidad.
                                     % Instancia las variables de la formula F con  valores (t o f)
                                     % que hacen cierta la formula

satisfactible1(F) :- \+ \+ satisfactible(F).  % Test de satisfactibilidad.
                                              % No instancia variables

insatisfactible(F) :- \+ satisfactible(F).    % Da igual poner \+ satisfactible1(F)
                                              % En ningun caso se ligan variables

tautologia(F) :- \+ (F es f).   

% Otra version
tautologia1(F) :- insatisfactible(no F).

% Una formula es contingente si para algunas valoraciones es verdadera y para otras falsa.
%        Dicho de otro modo, si es satisfactible pero no tautologia
%        Dicho de otro modo, si no es tautologia ni insatisfactible

contingente_mal(F) :-    % esta version es incorrecta!!
  satisfactible(F), 
  \+ tautologia(F).

contingente(F) :- 
  satisfactible1(F), 
  \+ tautologia(F).

% Otra version correcta
contingente1(F)  :- 
  \+ tautologia(F), 
  \+ insatisfactible(F).  

% Otra version incorrecta
contingente2(F)  :- 
  F es t,
  F es f.
