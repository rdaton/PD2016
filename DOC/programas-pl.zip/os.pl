/**************** Un poco de orden superior *************/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% map_rel(P,Xs,Ys) <-> P es el nombre de un predicado de aridad 2
%                        Xs es [X1,...,Xn]
%                        Ys es [Y1,...,Yn]
%                        se cumple P(Xi,Yi) se cumple para cada 1<=i<=n
% Por ejemplo,
% map_rel(member,[1,2,3],[[2,1],[2,1],[2,3]]) tiene éxito
% map_rel(member,[1,2,3],[[2,1],[],[2,3]]) falla
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

map_rel(P,[],[]).
map_rel(P,[X|Xs],[Y|Ys]) :-
  G =.. [P,X,Y],
  call(G),
  map_rel(P,Xs,Ys).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% all(P,Xs,Ys) <-> P es el nombre de un predicado de aridad 1
%                  y todos los elementos de la lista Xs cumplen P
% Por ejemplo
% all(atomic,[1,a,[],true]) tiene éxito
% all(atomic,[1,a,X,f(a)]) falla
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

all(P,[]).
all(P,[X|Xs]) :-
  G =.. [P,X],
  call(G),
  all(P,Xs).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% filter(P,Xs,Ys) <-> P es el nombre de un predicado de aridad 1
%                     Ys es la lista de todos los elementos de Xs que cumplen P
% Por ejemplo
% filter(atomic,[1,a,X,f(a)],L) tiene éxito con L=[1,a]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

filter(P,[],[]).
filter(P,[X|Xs],[X|Ys]) :-
  G =.. [P,X],
  call(G),
  !,
  filter(P,Xs,Ys).
  
filter(P,[X|Xs],Ys) :-
  filter(P,Xs,Ys).

